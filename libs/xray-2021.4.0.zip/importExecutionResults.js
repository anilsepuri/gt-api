const _ = require("lodash"),
    axios = require("axios").default,
    fs = require("fs"),
    logUtil = require("./util/logUtilities.js"),
    xrayUtilities = require("./util/xrayUtilities.js");

/**
 * Finds the every json cucumber report file (per feature)
 * then combines each json to create a single cucumber_report.json
 */
async function combineJSONFiles(reportsToBeMergedDir, pathToWriteReportTo) {
    fs.writeFile(pathToWriteReportTo, '', function(e) {if(e) throw  e;});
    let data = {};
    var p = new Promise((resolve, reject) => {
        xrayUtilities.walk(reportsToBeMergedDir, "json", function (err, files) {
            if (err)  {
                reject(console.error(err));
            }
            let index = 0;
            files.forEach(file => {
                let content = require(`${file}`);
                if (index === 0) {
                    data = content;
                }else {
                    data.push(content[0]);
                }
                index++;
            });
            resolve(data);
        });
    }).catch((error) => {
        reject(console.error(err));
    });
    return p.then(data => {
        if(p.status = "fulfilled" ){
            return fs.writeFileSync(pathToWriteReportTo,JSON.stringify(data));
        }else{
            throw new Error(p.reason);
        }
    })
}

/**
 * imports the results to xray form the cucumber_results.json file
 */
async function importCucumberExecutionResultsToJira(path) {
    const authorizationToken = await xrayUtilities.createAuthenticationToken();
    fs.readFile(path, "utf-8", function (err, data) {
        if (err){
            console.error(err);
            throw err;
        } else {
            const options = {
                method: "POST",
                url: "https://xray.cloud.xpand-it.com/api/v1/import/execution/cucumber",
                headers: {
                    Authorization: "Bearer " + authorizationToken,
                    "Content-Type" : "application/json"
                },
                data: data.toString()
            };
            axios(options).then((response) => {
                console.log("Test Execution Results are below:");
                console.log(response.data);
            })
                .catch((error) => {
                    logUtil.logHttpError(error);
                });
        }
    })
}

/**
 * imports the results to xray form the junit xml file and creates any corresponding tests that are not already in xray
 */
async function importJunitExecutionResultsToJira(dir){
    const authorizationToken = await xrayUtilities.createAuthenticationToken();
    fs.readFile(dir, "utf-8", function (err, data) {
        if (err) console.error(err);
        const options = {
            method: "POST",
            url: "https://xray.cloud.xpand-it.com/api/v1/import/execution/junit?projectKey=RU",
            headers: {
                Authorization: "Bearer " + authorizationToken,
                "Content-Type" : "text/xml"
            },
            data: data.toString()
        };
        axios(options).then((response) => {
            console.log(response.data);
        })
            .catch((error) => {
                logUtil.logHttpError(error);
            });
    })
}

module.exports = {
    importJunitExecutionResultsToJira,
    importCucumberExecutionResultsToJira,
    combineJSONFiles
};




