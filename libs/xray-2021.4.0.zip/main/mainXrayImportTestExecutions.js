global.projectId = process.argv.slice(2)[0];
global.featureDir = process.argv.slice(2)[1];
global.targetDir = process.argv.slice(2)[2];
const importExecutionResults = require("./../importExecutionResults.js"),
    cucumberFeaturesDir = "../../../" + global.featureDir,
    mergedReport = "../cucumber_report.json",
    updateReport = require("./../util/xrayreportfix.js"),
    updateJira = require("./../jira/updateJiraComponents.js"),
    excludedFolders = [],
    fileType = ".feature";

// fetch the jira ids for which the tests executions are to be imported
updateReport.fetchJiraIdsToBeImported().then(function () {
    // update the cucumber json report with tags from the feature file
    updateReport.updateReportWithJiraIds(mergedReport).then(function () {
        // import tests executions
        importExecutionResults.importCucumberExecutionResultsToJira(mergedReport).then(function () {
        }).catch(function(e){ process.exit(1); });
    }).catch(function(e){ process.exit(1); });
}).catch(function(e){ process.exit(1); });

// find and update Jira components
updateJira.findAndAssociateComponentsToTests(cucumberFeaturesDir,excludedFolders, fileType).then(function () {
}).catch(function(e){ process.exit(1); });
